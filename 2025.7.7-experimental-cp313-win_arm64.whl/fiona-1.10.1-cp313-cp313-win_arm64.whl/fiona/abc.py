"""Abstract base classes."""

from fiona._vsiopener import FileContainer, MultiByteRangeResourceContainer

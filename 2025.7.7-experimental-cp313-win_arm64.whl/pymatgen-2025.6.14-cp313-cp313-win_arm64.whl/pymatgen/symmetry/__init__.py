"""The symmetry package implements symmetry tools like spacegroup determination, etc."""

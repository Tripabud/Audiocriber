from ._api import file_reader

__all__ = [
    "file_reader",
]


def __dir__():
    return sorted(__all__)

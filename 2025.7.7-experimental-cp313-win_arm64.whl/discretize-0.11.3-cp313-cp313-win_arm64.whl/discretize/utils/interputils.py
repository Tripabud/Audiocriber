from discretize.utils.interpolation_utils import *  # NOQA F401,F403

raise ImportError(
    "Importing from discretize.interputils is deprecated behavoir. Please import "
    "from discretize.utils. This message will be removed in version 1.0.0 of discretize.",
)

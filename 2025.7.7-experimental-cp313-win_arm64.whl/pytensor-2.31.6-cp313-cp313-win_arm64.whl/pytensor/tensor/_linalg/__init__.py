# Register rewrites
import pytensor.tensor._linalg.solve
